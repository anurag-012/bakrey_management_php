<?php
include 'bake_header.php';
?>

						<div id="data">
							<div class="img-owl-left">
								<div class="owl-carousel" id="img-slide-owl-2">
									<div class="item" id="#item1">
										<img  src="<?php echo $row['prod_img'] ?>">
									</div>
									<div class="item" id="#item1">
										<img  src="<?php echo $row['prod_img_hover'] ?>">
									</div>
									<!-- <div class="item" id="#item1">
										<img  src="image/rose-quartz-roller_2_1200x1200.webp">
									</div> -->
								</div>
							</div>
							<div class="content-right">
								<div class="skin-gym-content-in-fancy-owl">
									<?php echo $row['prod_name'];?>
								</div>
								<div class="blank-div">
								</div>
								<div class="price-owl">
									INR <?php echo $row['price'];?> /-
								</div>
								<div>
									<form style="margin-left: 10px">
									<input style="font-size: 19px" type="button" name="" value="-" onclick="dec()">
									<input style="font-size: 19px;width: 40px" type="number" min="1" max="5" id="inc-dec-num" value="1">
									<input style="font-size: 19px" type="button" name="" value="+" onclick="inc()">
								</form>
								</div>
								<div style="margin: 15px 10px">
									<div class="add-2-cart">
										<a href="cart.php" style="text-decoration: none;">
										<div class="cart-button">
											ADD TO CART 
										</div>
										</a>
									</div>
								</div>
							</div>
						</div>
