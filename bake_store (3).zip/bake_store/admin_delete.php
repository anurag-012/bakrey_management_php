
<?php
include 'conn.php';
$delid=$_GET['id'];
if(isset($_GET['id']))
{

	$sqldel= "DELETE  FROM admin_prod_images WHERE prod_img_id=$delid";
	echo "$sqldel";
	if (mysqli_query($con,$sqldel)) {
		echo "data deleted Succesfully";
	}
	else
	{
		echo "query error".mysqli_error();
	}

}
else
{
	echo "query error".mysqli_error();
}
?>