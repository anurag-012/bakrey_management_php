<?php
include 'bake_header.php';	
$email=$_REQUEST['mail'];

$message=rand(10000,99999);

?>
<script type="text/javascript">

function validateform(){
	var x = document.getElementById("abc").value;
	var y = document.getElementById("xyz").value;
	if(x!=y){
	document.getElementById("message").innerHTML="!! Please enter correct OTP.";
	return false;
	}
}

</script>
<div class="bake-main">
	<div class="otp-main">
		<div class="otp-sub">
			<div class="auth">
				Authentication
			</div>
			<div class="pwd-ass-sub">
				For your security, we need to authenticate your request. We've sent an OTP to the email...<span style="font-weight:600;color: #484848;">
				<?php echo "$email"?></span>. Please enter it below to complete verification.
			</div>
			<?php
			echo "$message";
			?>
		</div>
		<form action="newpwd.php" onsubmit="return validateform()" >
			<input type="hidden" name="mail" value="<?php echo $email;?>" />
			<input type="hidden" id="abc"  value="<?php echo $message;?>" />
			<input class="inpt" required="" type="number" id="xyz"  placeholder="Enter OTP">
			<br>
			<a href="otp-pg.php?mail=<?php echo $email?>"> Resend OTP</a>
			<p id="message" style="color: red"></p>
			<input class="sub" type="submit" value="NEXT" />

		</form>
	</div>
</div>
	