<?php
include 'conn.php';
$mail=$_REQUEST['mail'];
$pid=$_REQUEST['p_id'];
$qty=$_REQUEST['qtybox'];
$price=$_REQUEST['price'];
$p_name=$_GET['p_name'];
$img=$_REQUEST['img'];
// $price=$_REQUEST['price'];
$total=$price*$qty;
$sql="SELECT * FROM cart WHERE email='$mail' AND prod_id=$pid";
echo "$sql";
$result=(mysqli_query($con,$sql));
// print_r($result);
if (mysqli_num_rows($result)>0) 
{ 
 while($row=mysqli_fetch_assoc($result))	
	{
		$conc = mysqli_connect("localhost","root","","bake_store") or die(mysqli_error());
		$a=$row['qty'];
		echo "$a";
		$s=$a+$qty;
		echo "$s";
		$total=$price*$s;
		$upd="UPDATE cart SET qty=$s,total=$total WHERE email='$mail' AND prod_id=$pid";
		
		if (mysqli_query($conc,$upd)) 
{
echo '<script>alert("Added to cart!");window.location.href="mycart.php"</script>';
echo "$upd";

}
else
{
	mysqli_error();
	
}
		
 }
	
}
else
{
$sql="INSERT INTO `cart` (email,prod_id,prod_name,price,image,qty,total) VALUES ('$mail','$pid','$p_name','$price','$img','$qty',$total);";
	echo "$sql";
	if (mysqli_query($con,$sql)) {
		echo '<script>alert("Added to cart!");window.location.href="mycart.php"</script>';
	}
	else
	{
		echo "query error".mysqli_error();
	}
	}
?>