<?php
include 'conn.php';
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="homepage.css">
</head>
<body>
<div class="main-division">
<div class="add-main">

<div class="add-title">
THE SWEET PLACE
</div>
CAKE ANS PASTRIES<br>
<p>
---------------------------------------------------------------------------------
</p>
<p style="text-align: left;font-size: 20px">
<?php
//$id=$_['id'];
//$sql_id = "SELECT MAX(o_id) from check_out";
//$result_id = mysqli_query($con,$sql_id);
// if ($result_id) {
//   // code...
// }
 //$id=$result_id['o_id'];
 //echo "id = ",$id;
//$id = 2;

$sql="select * from check_out WHERE o_id = (SELECT MAX(o_id) FROM check_out);";
$result=(mysqli_query($con,$sql));
//if (mysqli_num_rows($result)>0) 

if ($row=mysqli_fetch_assoc($result)) {

echo "customer name :".$row['name']."<br>";
echo "Address :".$row['address']."<br>";
echo "Mobile :".$row['m_no']."<br>";
echo "City :".$row['city']."<br>";
echo "Date :".$row['b_date']."<br>";
    
}
?>
<p>
----------------------------------------------------------------------------------
</p>


<?php
session_start();
$mail=$_SESSION['mail'];
$sql="SELECT * FROM cart WHERE email='$mail'";
$result=(mysqli_query($con,$sql));
if (mysqli_num_rows($result)>0)
{
?>
<div style="display:;">
<table>
<!-- <th>PRODUCT</th> -->
<th>Name</th>
<th>Price</th>
<th>Quantity</th>
<th>Total</th>
<?php
while($row=mysqli_fetch_assoc($result))
{
echo "<tr>";
?>
<style type="text/css">
td{
padding: 10px;
}
th
{
font-size: 22px;
font-family: sans-serif;
padding: 20px 20px 0px;
text-decoration:;
}
</style>
<!-- <td><input type="hidden" name="c_id" value="<?php echo $row['cart_id']?>"></td> -->
<!-- <td><img width="100px" src="<?php echo $row['image'] ?>"></td> -->


<?php

//echo "<td".$row['inv_id']."</td>";
echo "<td>".$row['prod_name']."</td>";
echo "<td>".$row['price']."</td>";
echo "<td>".$row['qty']."</td>";
echo "<td>".$row['total']."</td>";
echo "</tr>";
}
}
?>
</table>
<p>---------------------------------------------------------------------------------</p>
</div>
<div style="overflow: hidden;">
<div style="float: left;width: 45%;font-size: 25px">
TOTAL
</div>
<div style="float: left;width: 50%;font-size: 25px;font-weight: bold;text-align: right;">
<?php
$sqlc="SELECT SUM(total) as total FROM cart WHERE email='$mail'";
$result=mysqli_query($con,$sqlc);
if(mysqli_num_rows($result) > 0)
{
while($row=mysqli_fetch_assoc($result))
{
echo $row['total'];
}
}
?>
<div style="display: inline-block;">
/- Rs.
</div>
</div>

</div>

</div>
</div>
<script>
function pdf(){
window.print();
}
window.onload = pdf();
</script>
</body>
</html>