<?php
include'conn.php';
$newpwd=$_REQUEST['np'];
$repwd=$_REQUEST['rp'];
$email=$_REQUEST['mail'];
$newpwd="bd1908".md5($newpwd)."am610";

	$sqlupdate = "UPDATE sign_up SET  password='$newpwd' WHERE email_id='$email'";
	echo "$sqlupdate";
	if(mysqli_query($con,$sqlupdate))
	{
		echo "<script>alert('updated sucessfully');window.location.href='login-test.php';</script>";
	}
	else
	{
		echo "<script>alert('something wents wrong !!!')</script>";
	}

?>