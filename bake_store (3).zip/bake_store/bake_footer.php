<div class="footer-main">
	<div>	
		<div class="left-footer">
			<div class="left-footer-top">
				<div class="terms-condition">
					Terms and conditions
				</div>
			</div>
			<div class="left-footer-bot">
				<div class="sitemap">
					Sitemap
				</div>
			</div>
		</div>
		<div class="mid-footer">
			<div class="mid-footer-top">
				<div class="contectus">
					<a href="contact_us.php" style="text-decoration: none;color: #707070;"> Contact Us </a>
				</div>
			</div>
			<div class="mid-footer-bot">
				<div class="aboutus">
					<a href="aboutus.php" style="text-decoration: none;color: #707070;"> About Us </a>
				</div>
			</div>
		</div>
		<!-- <div class="right-footer">
			<div class="join-list">
				JOIN OUR MAILING LIST
			</div>
			<div class="mail-form">
				<form style="margin-left: 40px;" action="subscribe.php">
					<input type="email" class="mail-box" name="mail" placeholder="Enter your email"><br>
					<input type="submit" class="subscribe-button" name="" value="SUBSCRIBE">
				</form>
			</div>
		</div> -->
	</div>
	</div>
</body>
</html>