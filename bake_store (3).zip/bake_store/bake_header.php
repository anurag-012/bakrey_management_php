<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>bakers bunch</title>
	<link rel="stylesheet" type="text/css" href="bake.css">
	<style type="text/css">
		.error
		{
			color: #980c0c;
			font-size: 22px;
			font-weight: bold;
		}
	</style>
	<link rel="stylesheet" type="text/css" href="plugins/fancybox/dist/jquery.fancybox.css">
	<link rel="stylesheet" type="text/css" href="plugins/flex/flexslider.css">
	<script type="text/javascript" src="plugins/jquery-3.5.1.min.js"></script>
	<script type="text/javascript" src="plugins/flex/jquery.flexslider.js"></script>
	<script type="text/javascript" src="plugins/fancybox/dist/jquery.fancybox.js"></script>
	<link rel="stylesheet" type="text/css" href="plugins/owl/css/owl.carousel.css">
	<script type="text/javascript" src="plugins/owl/js/owl.carousel.js"></script>
	<script type="text/javascript" src="plugins/jquery.validate.min.js"></script>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500&display=swap" rel="stylesheet">

	<script type="text/javascript">
		function inc()
	{
		var abc=document.getElementById('inc-dec-num').value;
		abc++;
		document.getElementById("inc-dec-num").value=abc;
	}

	function dec()
	{
		document.getElementById("inc-dec-num").stepDown();
	}
		$(document).ready(function(){
		$('#flex').flexslider
		({
			animation:"fade",
			items:1,
			nav:true,
			slideshowSpeed:2000
		})
		$('#flex-last').flexslider
		({
			animation:"slide",
			items:1,
			nav:true,
			slideshowSpeed:3000
		})
		$("#img-slide-owl").owlCarousel
		({
			nav:false,
			loop:true,
			items:4
		})
		$("#img-slide-owl-2").owlCarousel
		({
			nav:true,
			loop:true,
			items:1,
			itemWidth:100,
			dots:true
		})
	});
		$("a#inline").fancybox({
			'hideOnContentClick': true,
			'transition':'elastic'
		});
		
	</script>
</head>
<body>
	
	<div class="bake-header">
		<div class="bake-header-top">
			<div class="bake-header-top-left">
					<div class="bake-header-top-left-nav">
						<div class="nav-bar-content1"><a href="bake_home.php" class="nav-bar-content-a">Home</a></div>	
						<div class="nav-bar-content"><a href="products.php?id=shop" class="nav-bar-content-a">All Products</a></div>
						<div class="nav-bar-content"><a href="aboutus.php"class="nav-bar-content-a">About Us</a></div>
						<div class="nav-bar-content"><a href="contact_us.php"class="nav-bar-content-a">Contact Us</a></div>
						<div class="nav-bar-content">
						<?php
	if(isset($_SESSION['fname']))
	{
	echo "Welcome ".$_SESSION['fname'];
	}
	else
	{

	}
	?>
	</div>
					</div>
			</div>
			<div class="bake-header-top-right">
				<div class="bake-header-top-right-text">
					The Sweet Place
				</div>
			</div>
		</div>
<div style="text-align: center;">
	
</div>
		<div class="bake-header-2">
			<div class="bake-header2-sub">
				<!-- <div class="bake-header-2-left">
					<img src="images/backeholic.png" width="220px">
				</div> -->
				<div class="bake-header-2-mid">
					<div class="nav-bar-sub">
						<div class="nav-bar-content-header2">
							<a href="product_type.php?id=1" class="nav-bar-content-a">CAKE</a>
						</div>	
						<div class="nav-bar-content-header2">
							<a href="product_type.php?id=2" class="nav-bar-content-a">PASTRY</a>
						</div>
						<div class="nav-bar-content-header2">
							<a href="product_type.php?id=3"class="nav-bar-content-a">DONUTS</a>
						</div>
						<div class="nav-bar-content-header2">
							<a href="product_type.php?id=4"class="nav-bar-content-a">COOKIES</a>
						</div>
						<div class="nav-bar-content-header2">
							<a href="products.php?id=shop"class="nav-bar-content-a">SHOP COLLECTIONS</a>
						</div>
						<div class="nav-bar-content-header2">
							<?php
		if(isset($_SESSION['mail']))
		{
						// echo "hiiiiiiiiiiiiiiiiiiiiii"
		?>
			<a href="logout.php"class="nav-bar-content-a">LOGOUT</a>
	<?php
		}
		else{
		?>
	<a href="login-test.php"class="nav-bar-content-a">LOGIN</a>
		<?php } ?>
						</div>
						<div class="nav-bar-content-header2">
							<a href="profile.php"class="nav-bar-content-a">USER PROFILE</a>
						</div>
					</div>
				</div>
		
	</div>
	<div class="cart-icon">
			<?php
			if((isset($_SESSION['mail'])))
			{
				?>
			
			<a href="mycart.php">
			<img src="images/bag2-512.webp" width="40px" style="position: relative;">
			</a>
			<?php
		}
		else
		{
			?>
			<a href="login-test.php">
			<img src="images/bag2-512.webp" width="40px" style="position: relative;">
			</a>
			<?php
		}
		?>
			
				<?php
				include 'conn.php';
				// $mail=$_SESSION['mail'];
				if(isset($_SESSION['mail']))  {?>
					<div class="prod-noti-txt">
						<?php
						$mail=$_SESSION['mail'];
					$sql="SELECT count(*) AS total FROM cart WHERE email='$mail'";
					// echo $sql;
				$result=mysqli_query($con,$sql);
				$data=mysqli_fetch_assoc($result);
				echo $data['total'];
			echo "</div>";

				}
				
				?>
		</div>
</body>
</html>