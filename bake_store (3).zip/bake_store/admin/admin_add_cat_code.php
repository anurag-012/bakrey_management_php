<?php
$con = mysqli_connect("localhost","root","","bake_store") or die(mysqli_error());
echo "Connected Succesfully.<br>";

$tid=$_REQUEST['type_id'];
$tnm=$_REQUEST['type_name'];

	$sql=" INSERT INTO admin_product_type (type_id,prod_type) VALUES ('$tid','$tnm')";
echo $sql."<br>";
if (mysqli_query($con,$sql))
 {
		echo "<script>alert('product type inserted');window.location.href='admin_view_cat.php';</script>";
	}
else
{
	echo "<script>alert('already exist');window.location.href='admin_add_cat.php';</script>";
}
?>