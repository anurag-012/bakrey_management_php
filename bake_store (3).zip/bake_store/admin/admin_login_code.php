<?php
include 'conn.php';
$email=$_REQUEST['mail'];
$pwd=$_REQUEST['pwd'];
$sql= "select * from admin_login where admin_mail='$email'";
echo "$sql";

$result=mysqli_query($con,$sql);
if(mysqli_num_rows($result))
{
	while($adm=mysqli_fetch_assoc($result))
	{
		if($adm['admin_pwd'] == $pwd && $adm['admin_mail']==$email)
		{
			 
			$_SESSION['email']=$adm['admin_mail'];
			echo "<script>alert('Logged in Succcessfully!');window.location.href='admin_header.php';</script>";
		}
		else
		{
			header('Location:login_admin_form.php?pass=wrong');
			mysql_error();
		}
	}
}
else 
{
	header('Location:admin_login_form.php?mail=wrong');
	echo "Email is wrong";
}
?>
