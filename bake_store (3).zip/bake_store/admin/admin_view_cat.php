<?php
include 'admin_header.php';
include 'conn.php';
?>
	<div class="admin-main">
		<div style="background-color: #ffffff75;width: fit-content;display: inline-block;margin: 40px">
		<?php
			$sql="SELECT * from admin_product_type";
			$result=mysqli_query($con,$sql);
			?>
			<table border="1" id="mytable">
				<thead>
				<tr>
						<th style="font-size: 30px;padding: 10px">Product Id</th>
					
						<th style="font-size: 30px;">Product Type</th>

						<th style="font-size: 30px;">Delete</th>

						<th style="font-size: 30px;">Edit</th>
				</tr>
			</thead>
			<tbody>
			<?php
			if (mysqli_num_rows($result)>0) {
				while ($row=mysqli_fetch_assoc($result)) {
					
						echo "<tr>";
							echo"<td>".$row['type_id']."</td>";
							echo"<td>".$row['prod_type']."</td>"; ?>

						    <td> <a href='admin_del_type.php?id="<?php echo $row['type_id'] ?>"'>DELETE</a></td>
							<td> <a href='admin_edit.php'>EDIT</a></td>
					</tr>
					</tabel>
					<?php
				}
			}	
		?>
	</tbody>
	</div>
	</div>
	<script type="text/javascript">
		$(document).ready( function () {
    $('#mytable').DataTable();
} );
	</script>
</body>
</html>