<?php
include 'admin_header.php';
include 'conn.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>
</head>
<body>
	<div class="admin-main">
		<div style="background-color: #ffffff75;width: fit-content;display: inline-block;margin: 40px">
		<?php
			$sql="SELECT * from sign_up";
			$result=mysqli_query($con,$sql);
			?>
			<table border="1" id="mytable">
				<thead>
				<tr>
						<th style="font-size: 30px;padding: 10px">First name</th>
					
						<th style="font-size: 30px;">Last name</th>
					
						<th style="font-size: 30px;">Address</th>
					
						<th style="font-size: 30px;">phone</th>
					
						<th style="font-size: 30px;">email</th>

						<th style="font-size: 30px;">city</th>
				</tr>
			</thead>
			<tbody>
			<?php
			if (mysqli_num_rows($result)>0) {
				while ($row=mysqli_fetch_assoc($result)) {
					
						echo "<tr>";
							echo"<td>".$row['f_nm']."</td>";
							echo"<td>".$row['l_nm']."</td>";
							echo"<td>".$row['address']."</td>";
							echo"<td>".$row['m_no']."</td>";
							echo"<td>".$row['email_id']."</td>";
							echo"<td>".$row['city']."</td>";
						echo"</tr>";
					echo "</tabel>";
				}

			}

		?>
		</tbody>
	</div>
	</div>
	<script type="text/javascript">
		$(document).ready( function () {
    $('#mytable').DataTable();
} );
	</script>
</body>
</html>