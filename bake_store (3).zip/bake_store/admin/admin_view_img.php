<?php
include 'admin_header.php';
include 'conn.php';
?>
<!DOCTYPE html>
<html>
<head>
	<!-- <meta charset="utf-8"> -->
	<title></title>
</head>
<body>
	<div class="admin-main">
		<div class="display-div">
		<?php
			$sql="SELECT * from admin_prod_images";
			$result=mysqli_query($con,$sql);
			?>
			<table border="1" id="mytable">
				<thead>
				<tr>
						<th style="font-size: 30px;padding: 10px">Product id</th>
					
						<th style="font-size: 30px;">Product type</th>
					
						<th style="font-size: 30px;">Product name</th>
						<th style="font-size: 30px">Product price</th>
					
						<th style="font-size: 30px;">Product type id</th>
					
						<th style="font-size: 30px;">Product image</th>
						<th style="font-size: 30px;">Delete</th>
						<th style="font-size: 30px;">Edit</th>

				</tr>
			</thead>
			<tbody>
			<?php
			if (mysqli_num_rows($result)>0) {
				while ($row=mysqli_fetch_assoc($result)) {

					
						echo "<tr>";
							echo"<td>".$row['prod_img_id']."</td>";
							echo"<td>".$row['prod_type']."</td>";
							echo"<td>".$row['prod_name']."</td>";
							echo"<td>".$row['price']."</td>";
							echo"<td>".$row['type_id']."</td>";
							
							echo"<td>";?><img width="100px" src="<?php echo $row['prod_img'];?>"></td>
								
								<td> <a href='admin_delete.php?id=<?php echo $row["prod_img_id"];?>'>DELETE</a></td>
								<td> <a href='admin_edit_prod.php?id=<?php echo $row["prod_img_id"];?>'>EDIT</a></td>

						</tr>
					
					<?php
				}

			}

		?>

	</tbody>
	</table>
	</div>
	</div>
<script type="text/javascript">
		$(document).ready( function () {
    $('#mytable').DataTable();
} );
	</script>
</body>
</html>
	