<?php
include 'admin_header.php';
?>
<div class="admin-main">

	<form id="myform" method="post" action="uploadimg_admin.php" style="background-color: #04363e42; width: fit-content;display: inline-block; padding: 30px;margin:40px; border: solid 1px #04363e42;
																border-radius: 30px;" enctype="multipart/form-data" >
<table>
	
	<tr>
	<td>product type:</td><td><input type="text" name="prod_type" required="" /></td>
	</tr>
	<tr>
	<td>product name:</td><td><input type="text" name="prod_name" required="" /></td>
	</tr>
	<tr>
	<td>product price:</td><td><input type="text" name="prod_price" required="" /></td>
	</tr>
	<tr>
	<td>product id:</td><td><input type="text" name="prod_id" required="" /></td>
	</tr>
	<tr>
	<td>image</td><td><input type="file" name="file" accept="images/*" required="" /></td>
	</tr>
	<tr>
	<td>discription:</td><td><input type="text" name="desc"/></td>
	</tr>
	<tr>
	<td></td><td><input type="submit" value="submit" /></td>
	</tr>
</table>
</form>
</div>
<script type="text/javascript">
$(document).ready(function(){
			$('#myform').validate({
			rules:{
				prod_type:'required',
				prod_name:'required',
				prod_price:'required',
				prod_id:'required',
				file:'required',
				desc:'required'

			}
			
		});
		});
</script>

































