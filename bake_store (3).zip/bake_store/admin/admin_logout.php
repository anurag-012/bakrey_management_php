<?php
session_start();

unset($_SESSION['email']);
echo "<script>alert('Logged Out Succcessfully!');window.location.href='admin_login_form.php';</script>";
?>