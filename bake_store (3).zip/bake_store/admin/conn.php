<?php
$con = mysqli_connect("localhost","root","","bake_store") or die(mysqli_error());
?>