<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>

<div class="admin-login-main">
	<div class="back-img">
		<img src="images/b-slide11.jpg" height="650px;" width="1325px;">
	</div>
		<div class="admin-login-sub">
		<div class="admin-login">
			Admin Login
		</div>
		<form action="admin_login_code.php" method="post" >
			<input class="inpt" type="Email" name="mail" placeholder="Enter your Email" required="">
			<p style=" color: #cc0000; font-family: 'Poppins';">
				<?php 
				if(isset($_GET['mail']))
				{
					echo "!! email wrong";
				}
			 ?>
			 </p>
			<br>
			<input class="inpt" type="password" name="pwd" placeholder="Enter your password " required="" >
			<p style=" color: #cc0000; font-family: 'Poppins';">
				<?php 
				if(isset($_GET["pass"]))
				{
					echo "!! password wrong";
				}
			 ?> 
			</p>
			 <br>
			<input class="sub" type="submit" value="Log In">
		</form>
	</div>
</div>

</body>
</html>