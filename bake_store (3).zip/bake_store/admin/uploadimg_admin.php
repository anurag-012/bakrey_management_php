<?php
$con = mysqli_connect("localhost","root","","bake_store") or die(mysqli_error());
echo "Connected Succesfully.<br>";

$type=$_REQUEST['prod_type'];
$name=$_POST['prod_name'];
$price=$_POST['prod_price'];
$b=$_FILES['file']['tmp_name'];
$c='images//'.$_FILES['file']['name'];
$desc=$_REQUEST['desc'];
$pid=$_POST['prod_id'];
// echo $name."<br>";


if(move_uploaded_file($b,$c))
	{
		echo "Uploaded successfully"."<br>";
	}else{
		echo "Upload failed";
	}
	$sql="  INSERT INTO admin_prod_images (prod_type,prod_name,price,prod_img,type_id,discription)VALUES('$type','$name','$price','$c','$pid','$desc');";
echo $sql."<br>";
if (mysqli_query($con,$sql))
 {
		echo "<script>alert('product inserted');window.location.href='admin_view_img.php';</script>";
	}
else{
	echo "query error".mysqli_error();
}
?>