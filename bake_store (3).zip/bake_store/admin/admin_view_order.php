<?php
include 'admin_header.php';
include 'conn.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>
</head>
<body>
	<div class="admin-main">
		<div style="background-color: #ffffff75;width: fit-content;display: inline-block;margin: 40px">
		<?php
			$sql="SELECT * from cart";
			$result=mysqli_query($con,$sql);
			?>
			<table border="1" id="mytable">
				<thead>
				<tr>
						<th style="font-size: 30px;padding: 10px">Email</th>
					
						<th style="font-size: 30px;">Order id</th>
					
						<th style="font-size: 30px;">product</th>
					
						<th style="font-size: 30px;">Price</th>
					
						<th style="font-size: 30px;">Quantity</th>

						<th style="font-size: 30px;">Total</th>
						<!-- <th style="font-size: 30px;">Status</th> -->
						<!-- <th style="font-size: 30px;">View</th> -->

				</tr>
			</thead>
			<tbody>
			<?php
			if (mysqli_num_rows($result)>0) {
				
				while ($row=mysqli_fetch_assoc($result)) {
					
						echo "<tr>";
							echo"<td>".$row['email']."</td>";
							echo"<td>".$row['prod_id']."</td>";
							echo"<td>".$row['prod_name']."</td>";
							echo"<td>".$row['price']."</td>";
							echo"<td>".$row['qty']."</td>";
							echo"<td>".$row['total']."</td>";
							?>
							
							<?php
						echo"</tr>";
				}

			}

		?>
	</tbody>
</table>
<script type="text/javascript">
	$(document).ready( function () {
    $('#mytable').DataTable();
} );
</script>
	</div>
	</div>
