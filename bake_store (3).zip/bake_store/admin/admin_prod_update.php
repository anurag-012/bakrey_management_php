<?php
include 'conn.php';
$type=$_REQUEST['prod_type'];
$name=$_REQUEST['prod_name'];
$price=$_REQUEST['prod_price'];
$tid=$_REQUEST['prod_id'];
$img='images/'.$_REQUEST['file'];
$editid=$_GET['id'];

$updt="UPDATE admin_prod_images SET prod_type='$type' , prod_name='$name' , price='$price' , prod_img='$img'  , type_id='$tid'  WHERE prod_img_id='$editid' ";
echo "$updt";
if (mysqli_query($con,$updt)) 
{
echo "<script>alert('updated sucessfully');window.location.href='admin_view_img.php';</script>";

}
else
	{
		echo "<script>alert('something wents wrong !!!')</script>";
	}
?>