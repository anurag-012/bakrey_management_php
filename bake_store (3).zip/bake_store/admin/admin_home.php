<?php
include 'admin_header.php';
include 'conn.php';
?>
<div class="admin-main">
	<div style="display: inline-block; padding: 20px">
		<a href="admin_view_user.php">
			<div class="admin-activity">
				<div class="admin-activity-txt">User<div>
					<div style="margin-top: 12px;">
					<?php
						$sql="SELECT count(*) AS total FROM sign_up"; 
						$result=mysqli_query($con,$sql);
						$data=mysqli_fetch_assoc($result);
						echo $data['total'];
						echo "</div>";
					?>
					</div>
				</div>
			</div>
		</a>
		<a href="admin_view_img.php">
			<div class="admin-activity" style="background: #bbb2c5;">
				<div class="admin-activity-txt" style="color: #552e7d;">Products<div>
					<div style="margin-top: 12px;">
					<?php
						$sql="SELECT count(*) AS total FROM admin_prod_images"; 
						$result=mysqli_query($con,$sql);
						$data2=mysqli_fetch_assoc($result);
						echo $data2['total'];
						echo "</div>";
					?>
					</div>
				</div>
			</div>
		</a>
		<a href="admin_view_order.php">
			<div class="admin-activity" style="background: #cfb8b3;">
				<div class="admin-activity-txt" style="color: #8b4a4a">Orders<div>
					<div style="margin-top: 12px;">
					<?php
						$sql="SELECT count(*) AS total FROM cart"; 
						$result=mysqli_query($con,$sql);
						$data2=mysqli_fetch_assoc($result);
						echo $data2['total'];
						echo "</div>";
					?>
					</div>
				</div>
			</div>
		</a>
	</div>	
</div>