<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>admin panel</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
	<style type="text/css">
		.error
		{
			color: red;
		}
	</style>
</head>
<script type="text/javascript" src="../plugins/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../plugins/jquery.validate.min.js"></script>
<body>
	
	<div class="admin-main">
		<div class="admin-header">
			<div class="admim-header-sub">
				<div class="admin-header-left">
					<div class="admin-header-left-sub">
						<img src="images/logo.jpg" width="200px">
					</div>
				</div>
				<div class="admin-header-mid">
					Management Desk
				</div>
				<div class="admin-header-right">
					<div class="butie-header-2-right-sub">
						<div class="user-icon">
							<a href="#" class="user">
								<img src="images/avatar2_profile-512.png" width="30px">
							</a>
								<span style="color: #04223e;">
									<?php
									if(isset($_SESSION['email']))
										echo "";

									{
										echo "Hello Admin ! ";?>
										<a href="admin_logout.php" style="text-decoration: none; color: red">
									Logout</a>

									<?php }
									?>
								</span>
									
								</div>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="admin-nav-bar">
				<div class="nav-bar-sub">
					<div class="nav-bar-content-header">
							<a href="admin_home.php" class="nav-bar-content-a">HOME</a>
						</div>	
						<div class="nav-bar-content-header">
							<a href="admin_add_cat.php" class="nav-bar-content-a">ADD CATEGORY</a>
						</div>	
						<div class="nav-bar-content-header">
							<a href="img_prod_form.php" class="nav-bar-content-a">ADD PRODUCT</a>
						</div>
						<div class="nav-bar-content-header">
							<a href="admin_view_user.php" class="nav-bar-content-a">VIEW USERS</a>
						</div>
						<div class="nav-bar-content-header">
							<a href="admin_view_img.php" class="nav-bar-content-a">VIEW PRODUCTS</a>
						</div>
						<div class="nav-bar-content-header">
							<a href="admin_view_cat.php" class="nav-bar-content-a">VIEW CATEGORY</a>
						</div>
					</div>
			</div>
		</div>
	</div>
