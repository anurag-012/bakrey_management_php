<?php
include 'admin_header.php';
?>
<div class="admin-main">
	<form id="myform" method="post" action="admin_add_cat_code.php" style="width: fit-content;
																display: inline-block;
																padding: 40px;
																margin:40px;
																border: solid 1px #04363e42;
																border-radius: 30px;
																background-color: #04363e42;" enctype="multipart/form-data" >
<table>
	
<table>
	<tr>
	<td>type id:</td><td><input type="text" name="type_id" required="" /></td>
	</tr>
	<tr>
	<td>product type:</td><td><input type="text" name="type_name" required="" /></td>
	</tr>
	<tr>
	<td></td><td><input type="submit" value="submit" /></td>
	</tr>
</table>
</form>
</div>
<script type="text/javascript">
$(document).ready(function(){
			$('#myform').validate({
			rules:{
				type_id:'required',
				type_name:'required',
			}
			
		});
		});
</script>

































