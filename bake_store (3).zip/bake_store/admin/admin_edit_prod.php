<?php
include 'admin_header.php';
include 'conn.php';
?>
<div class="admin-main">
	<div class="display-div">
		<?php
		$editid=$_GET['id'];
		if(isset($_GET['id']))
			$sql="SELECT * FROM admin_prod_images WHERE prod_img_id=$editid";
		$result=mysqli_query($con,$sql);
		if(mysqli_num_rows($result)>0)
		{
			while ($row=mysqli_fetch_assoc($result)) {?>
				<form id="myform" action="admin_prod_update.php?id=<?php echo $editid ?>" method="post">
					<table>
						<tr>
						<td>product id:</td><td><input type="text" required="" name="prod_type" readonly="" value="<?php echo $row['prod_img_id']?>"/></td>
						</tr>
						<tr>
						<td>product type:</td><td><input type="text" required="" name="prod_type" value="<?php echo $row['prod_type']?>" /></td>
						</tr>
						<tr>
						<td>product name:</td><td><input type="text" required="" name="prod_name" value="<?php echo $row['prod_name']?>" /></td>
						</tr>
						<tr>
						<td>product price:</td><td><input type="text" required="" name="prod_price" value="<?php echo $row['price']?>" /></td>
						</tr>
						<tr>
						<td>product id:</td><td><input type="text" required="" name="prod_id" value="<?php echo $row['type_id']?>" /></td>
						</tr>
						<tr>
						<td>image :</td>
						<td>
							<img width="100" src='<?php echo $row["prod_img"]?>'>
						</td>
						<td><input type="file" name="file" accept="images/*"/></td>
						</tr>
						<tr>
						<td></td><td><input type="submit" value="submit" /></td>
						</tr>
					</table>
				</form>
				<?php
			}
		}?>
	</div>
</div>
<script type="text/javascript">
$(document).ready(function(){
			$('#myform').validate({
			rules:{
				prod_type:'required',
				prod_name:'required',
				prod_price:'required',
				prod_id:'required',
				file:'required',
			}
			
		});
		});
</script>

		
		