
<?php
include 'conn.php';
$delid=$_GET['id'];
if(isset($_GET['id']))
{

	$sqldel= "DELETE  FROM admin_product_type WHERE type_id=$delid";
	// echo "$sqldel";
	if (mysqli_query($con,$sqldel)) {
		echo "<script>alert('data deleted Succesfully');window.location.href='admin_view_cat.php'</script>";

	}
	else
	{
		echo "query error".mysqli_error();
	}

}
else
{
	echo "query error".mysqli_error();
}
?>