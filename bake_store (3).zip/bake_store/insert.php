<?php
include 'conn.php';//echo "Connected Succesfully.<br>";

//$tid=$_REQUEST['type_id'];
$tnm=$_REQUEST['fname'];
$m_no=$_REQUEST['phone'];
$pin=$_REQUEST['pin'];
$add=$_REQUEST['add'];
$city=$_REQUEST['city'];
$date=date("Y-m-d H:i:s");

$sql="INSERT INTO check_out (name,m_no,pincode,address,city,b_date) VALUES ('$tnm','$m_no','$pin','$add','$city','$date')";
echo $sql."<br>";
 if (mysqli_query($con,$sql))
 {
		header('Location:bill.php');
	}
	else
	{
		echo "query error".mysqli_error($con);
	}
/*else
{
	echo "<script>alert('already exist');window.location.href='mycart.php';</script>";
}*/
?>