<?php
	include 'bake_header.php';
?>
<div class="bake-main">

	<?php
$con = mysqli_connect("localhost","root","","bake_store") or die(mysqli_error());
$result_per_page=4;
$x=$_REQUEST['id'];
if(isset($_SESSION['mail']))
{
$mail=$_SESSION['mail'];
}
else
{
	$mail="NULL";
}
$sql= "SELECT * FROM admin_prod_images where type_id='$x'";
$result=mysqli_query($con,$sql);
if(mysqli_num_rows($result) > 0)
{
	while($row=mysqli_fetch_assoc($result))
	{
	?>
	
	<div class="item" style="display: inline-block;margin: 25px">
		<a href="add-to-cart.php?id=<?php echo $x;?>&p_id=<?php echo $row['prod_img_id']?>&p_name=<?php echo $row['prod_name'];?>&mail=<?php echo $mail?>&price=<?php echo $row['price']?>&img=<?php echo $row['prod_img']; ?>">
		<div class="item-img">
			<img src="<?php echo $row['prod_img'] ?>" alt="" width=" 250px">
			<div class="over-img">
				<div class="div-main-over-img">
					<img id="over-img" src="<?php echo $row['prod_img_hover'] ?>" width="250px">
				</div>
				<div class="q-view">
					<div>
						<a  href="add-to-cart.php?id=<?php echo $x;?>&p_name=<?php echo $row['prod_name']?>&p_id=<?php echo $row['prod_img_id']?>&mail=<?php echo $mail?>&price=<?php echo $row['price']?>&img=<?php echo $row['prod_img']?>" class="q-view-txt">QUICK VIEW </a>
						
					</div>
				</div>
			</div>
		</div>
	</a>
		<div class="disc-prod-main">
			<div class="prod-name" style="font-size: 15px;">
			<?php echo $row['prod_type'];?>
			</div>
			<div class="disc-prod" style="font-size: 18px;width: 235px">
			<?php echo $row['prod_name'];?>
			</div>
			<div class="price" style="font-size: 18px;">
			INR <?php echo $row['price'];?> /-
			</div>
		</div>
		<a href="add-to-cart.php?id=<?php echo $x;?>&p_name=<?php echo $row['prod_name']?>&p_id=<?php echo $row['prod_img_id']?>&mail=<?php echo $mail?>&price=<?php echo $row['price']?>&img=<?php echo $row['prod_img']?>" style="text-decoration: none;">
			<div class="ad-2-cart">
				<div class="cart-button">
					ADD TO CART 
				</div>
			</div>
		</a>
	</div>
	
<?php
	}

}
?>
<?php
include 'bake_footer.php';
?>
