<?php
	include 'bake_header.php';
	include'conn.php';
	$mail= $_SESSION['mail'];
if(isset($_SESSION['mail']))
	{
		$sql= "SELECT * FROM sign_up where email_id='$mail'";
		$result=mysqli_query($con,$sql);
		if(mysqli_num_rows($result) > 0)
		{
			
			while($row=mysqli_fetch_assoc($result))
			{
				?>
			<div class="bake-main">
   			<!-- <img src="image/Jade.jpg" width="1200px" style="position: relative;margin-top: 20px"> -->
   			<div class="upd_form_div">
            <form id="profile" action="update.php" method="post">
        <table style=" display: inline-block;margin: 50px" >
            	
                <tr>
                    <input type="hidden" name="id"  value="<?php echo $row['u_id']; ?>">
                </tr>
                <tr>
                    <td>
                        <label>Name : </label>
                    </td>
                    <td>
                        <input  class="sfrm" type="text" id="fname" name="fname" value="<?php echo $row['f_nm']; ?>">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Surname : </label>
                    </td>
                    <td>
                        <input type="text" class="sfrm"  name="lname" value="<?php echo $row['l_nm']; ?>">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Phone no : </label>
                    </td>
                    <td>
                        <input type="text" class="sfrm" id="n2" onkeypress="checkphone()" name="phone" value="<?php echo $row['m_no']; ?>">
                        <span id="n2error" style="color: red"></span>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Email id : </label>
                    </td>
                    <td>
                        <input type="email" readonly="" class="sfrm" name="mail" value="<?php echo $row['email_id']; ?>">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Address : </label>
                    </td>
                    <td>
                        <input type="address" readonly="" class="sfrm" name="add" value="<?php echo $row['address']; ?>">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Password : </label>
                    </td>
                    <td>
                        <input type="password" readonly="" class="sfrm" name="pwd" value="<?php echo $row['password']; ?>">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>City : </label>
                    </td>
                    <td>
                        <input type="text" class="sfrm" name="city" value="<?php echo $row['city']; ?>">
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <center>
                            <input class="sign-bt" style="margin-left: 118px; width: 394px;" type="submit" name="submit" value="UPDATE" id="submit">
                        </center>
                    </td>
                </tr>
        </table>

            </form>
    </div>
</div>
	
			
			<?php
			}
		}
		else
		{
			echo "<script>alert('Something wents wrong')</script>";
		}
	}
else 
	{
		echo "<script>alert('login first');window.location.href='login-test.php';</script>";
	}
	?>


	<script type="text/javascript">
		$(document).ready(function(){
			$("#profile").validate({
			rules: {
				fname: "required",
				phone:"required"
			},
			
			
			// submitHandler:function(profile)
			// {
			// 	$.ajax({
			// 		url:"update.php",
			// 		type:"post",
			// 		data:$("#profile").serialize(),
			// 		success:function(data)
			// 		{
			// 			console.log(data);
			// 			if (data=="update") {
			// 				 alert("updated");
   //                          // window.location.href="bake_home.php";
			// 			}else{
   //                          alert("wrong");
   //                      }
			// 		}
			// 	})
			// }
		});
	});
	</script>
<?php
include 'bake_footer.php'
?> 