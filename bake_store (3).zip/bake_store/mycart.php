<?php
include 'conn.php';
include 'bake_header.php';

?>
<div class="bake-main">
<?php
$mail=$_SESSION['mail'];
$sql="SELECT * FROM cart WHERE email='$mail'";
// echo $sql;
$result=(mysqli_query($con,$sql));

if (mysqli_num_rows($result)>0) 
{
	?>
	<div style="display: inline-block;">
	<table style="float: left;border-right-style: double;
    border-right-color: #988063;margin: 50px 0px; font-family: 'Archivo', sans-serif;">
		<th></th>
		<th></th>

		<th>PRODUCT</th>
		<th>Name</th>
		<th>Price</th>
		<th>quantity</th>
		<th>Total</th>
		<?php
	while($row=mysqli_fetch_assoc($result))	
	{
		echo "<tr>";
		?>
		<style type="text/css"> 
			td{
				padding: 10px;
			}
			th
			{
				font-size: 22px;
				font-family: sans-serif;
				padding: 20px 20px 0px;
				text-decoration: underline;
			}
		</style>
		<td><input type="hidden" name="c_id" value="<?php echo $row['inv_id']?>"></td>
		<td> <a href='prod_del.php?c_id=<?php echo $row["inv_id"]?>'>DELETE</a></td>
		<td><img width="100px" src="<?php echo $row['image'] ?>"></td>
		

		<?php
		echo "<td>".$row['prod_name']."</td>";
		echo "<td>".$row['price']."</td>";
		echo "<td>".$row['qty']."</td>";
		echo "<td>".$row['total']."</td>";
		echo "</tr>";
	}
	?>
	</table>
	<div class="show-cart-right" style="float:left;margin: 100px 50px ">
		<div class="total-txt" style="margin-bottom: 15px; font-family: 'Archivo', sans-serif;">
			CART TOTAL
		</div>
		<div class="blank-div" style="width: 300px;height:1px; background-color: black">
		</div>
		<div style="overflow: hidden;text-align: right;margin: 12px">
			<div style="float: left; font-family: 'Archivo', sans-serif;">
				TOTAL
			</div>
			<?php
			$sqlc="SELECT SUM(total) as total FROM cart WHERE email='$mail'";
			$result=mysqli_query($con,$sqlc);
			if(mysqli_num_rows($result) > 0)
			{
				while($row=mysqli_fetch_assoc($result))
			{
				echo $row['total'];
			}

			
			}
			?>
			<div style="display: inline-block; font-family: 'Archivo', sans-serif;">
				/- Rs.
			</div>
		</div>
		<div>
			<div class="cont-shoping" style="font-family: 'Archivo', sans-serif;">
					<a href="#" onclick="history.back();return false;"> Continue Shopping</a>
			</div>
			<!-- <div class="chekout" style="font-family: 'Poppins', sans-serif;">
				Chek Out
			</div> -->
			<p style="color: #da3301; font-size: 20px; font-family: 'Archivo', sans-serif;">
				NOTE : Accept Cash On Delivery Only
			</p>
			<div >
					<form action="checkout.php"><input type="submit" name="sub" value="check-out"></form>
			</div>
		</div>
	</div>
</div>
<?php
}
else
{
	?>
	<div class="div-for-empty">
		<img src="image/source.gif" width="250px">
	</div>
	<div  class="empty-txt">
		<div style="font-size: 30px;float: left;margin-top: 17px; font-family: 'Archivo', sans-serif;">
			Oops!!!..Empty Cart..
		</div>
		<div style="float: left; font-family: 'Archivo', sans-serif;">
			<img src="image/36968-2-sad-emoji-image-thumb.png" width="50px" style="margin-top: 10px">
		</div>
	</div>
	<div class="for-shopping" style="font-family: 'Archivo', sans-serif;">
		<a href="products.php?id=1"><div class="go-for-txt">GO FOR SHOPPING</div></a> 
	</div>
<?php
// mysqli_error();
}
?>
</div>
<?php
include 'bake_footer.php'
?> 