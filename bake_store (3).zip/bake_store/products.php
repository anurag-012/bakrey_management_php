<?php
	include 'bake_header.php';
?>
<div class="bake-main">

	<?php
$con = mysqli_connect("localhost","root","","bake_store") or die(mysqli_error());
// echo "Connected Succesfully.<br>";
$result_per_page=7;
$sql= "SELECT * FROM admin_prod_images";
$result=mysqli_query($con,$sql);
 // $row = mysqli_fetch_array($result, MYSQL_NUM );
 //  $totalproduct = $row[0];
$number_of_img= mysqli_num_rows($result);
if(mysqli_num_rows($result) > 0)
{
	$number_of_pages=$number_of_img/$result_per_page;
	//$number_of_pages=ceil($number_of_pages);

	if(isset($_GET['page']))
	{
		$page=$_GET['page'];
		
	}else
	{
		$page=1;
	}

	$this_page_result=($page-1)*$result_per_page;


	$sql="SELECT * FROM admin_prod_images LIMIT ".$this_page_result.','.$result_per_page;
	$result=mysqli_query($con,$sql);
	$id=1;
	// $x=$_REQUEST['id'];
	if(isset($_SESSION['mail']))
{
$mail=$_SESSION['mail'];
}
else
{
	$mail="NULL";
}

	while($row=mysqli_fetch_assoc($result))
	{
?>


<div class="item" style="display: inline-block;margin: 25px">
	<a href="add-to-cart.php?id=<?php echo $x;?>&p_id=<?php echo $row['prod_img_id']?>&p_name=<?php echo $row['prod_name'];?>&mail=<?php echo $mail?>&price=<?php echo $row['price']?>&img=<?php echo $row['prod_img']; ?>">
	<div class="item-img">
		<img src="<?php echo $row['prod_img'] ?>" alt="" width=" 200px">
		<div class="over-img">
			<div class="div-main-over-img">
				<img id="over-img" src="<?php echo $row['prod_img_hover'] ?>" width="250px">
			</div>
			<div class="q-view">
				<div>
					<a href="add-to-cart.php?id=<?php echo $x;?>&p_id=<?php echo $row['prod_img_id']?>&p_name=<?php echo $row['prod_name'];?>&mail=<?php echo $mail?>&price=<?php echo $row['price']?>&img=<?php echo $row['prod_img']; ?>" class="q-view-txt">QUICK VIEW </a>
				</div>
			</div>
		</div>
	</div>
</a>
	<div class="disc-prod-main">
		<div class="prod-name" style="font-size: 15px;">
		<?php echo $row['prod_type'];?>
		</div>
		<div class="disc-prod" style="font-size: 18px;width: 235px">
		<?php echo $row['prod_name'];?>
		</div>
		<div class="price" style="font-size: 18px;">
		INR <?php echo $row['price'];?> /-
		</div>
	</div>
	<div class="ad-2-cart">
		<a href="add-to-cart.php?id=<?php echo $x;?>&p_name=<?php echo $row['prod_name']?>&p_id=<?php echo $row['prod_img_id']?>&mail=<?php echo $mail?>&price=<?php echo $row['price']?>&img=<?php echo $row['prod_img']?>" style="text-decoration: none;">
			<div class="ad-2-cart">
				<div class="cart-button">
					ADD TO CART 
				</div>
			</div>
		</a>
	</div>
</div>

<?php
}?>
<br>
<div class="pg-no-main" style="margin: 25px;">
<?php
for($page=1;$page<=ceil($number_of_pages);$page++)
	{
		echo '<a class="page-no" href="products.php?page=' . $page . '">' . $page . '</a>';
	}
}
?>
</div>
</div>

<?php
	include 'bake_footer.php';
?>