<?php
	include 'bake_header.php';
?>
<div class="bake-main">
	<div class="forgot-pwd-main">
		<div class="pwd-ass-sub-main">
			<div class="Pass-ass">
				Password Assistance
			</div>
			<div class="pwd-ass-sub">
				Enter your email address associated with your Skin Beauty Bar account.
			</div>
		</div>
		<div class="frm">
			<form action="otp-pg.php" method="post">
				<input class="inpt" type="email" name="mail" placeholder="Enter email" required=""><br>
				<input class="sub" type="submit" name="" value="SUBMIT">
			</form>
		</div>
	</div>
</div>
