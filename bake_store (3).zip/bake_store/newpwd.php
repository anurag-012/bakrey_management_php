<?php
include 'bake_header.php';
$email=$_REQUEST['mail'];
?>
<script type="text/javascript">

function validatepwd(){
	var x = document.getElementById("npw").value;
	var y = document.getElementById("rpw").value;
	if(x!=y){
	document.getElementById("message").innerHTML="password not match";
	return false;
	}
}
</script>
<div class="bake-main">
	<div class="forgot-pwd-main">
		<form action="updatepwd.php" method="post" onsubmit="return validatepwd()">

		<input type="email" hidden="" name="mail" value="<?php echo $email;?>" />

		<input class="inpt" type="password" id="npw" name="np" required="" placeholder="Enter new password" /><br>
		<input class="inpt" type="password" id="rpw" name="rp" required="" placeholder="Re-Enter password" />
		<p id="message"></p>
		<input class="sub" type="submit" value="submit" />

		</form>
		</div>
</div>
<!-- <?php
//include 'skin_footer.php'
?> -->