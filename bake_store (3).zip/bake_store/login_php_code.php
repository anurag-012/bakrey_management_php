<?php
$con = mysqli_connect("localhost","root","","bake_store") or die(mysqli_error());
session_start();
$mail=$_REQUEST['mail'];
$pwd=$_REQUEST['pwd'];

$pwd="bd1908".md5($pwd)."am610";

$sql= "select * from sign_up where email_id='$mail'";

$result=mysqli_query($con,$sql);
// echo mysqli_num_rows($result);
if(mysqli_num_rows($result) == 1)
{
	$abc=mysqli_fetch_assoc($result);
	/*echo $abc['password']."<br>"; 
	echo $pwd."<br>";die;
*/
	
		if($abc['password'] == $pwd)
		{
			$_SESSION['fname']=$abc['f_nm'];
			$_SESSION['mail']=$abc['email_id'];
			$_SESSION['uid']=$abc['u_id'];
			// echo "<script>window.location.href='bake_home.php';</script>";
			echo ".";
		}
		else
		{
			echo "password wrong";
		}
	
}
else 
{
	echo "Email is wrong";
}
	
?>