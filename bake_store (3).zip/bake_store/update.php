<?php
	include 'conn.php';

$fnm=$_REQUEST['fname'];
$lnm=$_REQUEST['lname'];
$pno=$_REQUEST['phone'];
$pwd=$_REQUEST['pwd'];
$id=$_REQUEST['id'];


	$sqlupdate = "UPDATE sign_up SET f_nm='$fnm' , l_nm='$lnm' , m_no='$pno' , password='$pwd' WHERE u_id='$id'";
	// echo "$sqlupdate";

	if(mysqli_query($con,$sqlupdate))
	{
		echo "<script>alert(' Updated successfully !!!');window.location.href='bake_home.php'</script>";
	}
	else
	{
		echo "<script>alert('something wents wrong !!!')</script>";
		// header('Location:profile.php');
	}
		
?>