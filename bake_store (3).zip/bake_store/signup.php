<?php
	$con = mysqli_connect("localhost","root","","bake_store") or die(mysqli_error());
	echo "Connected Succesfully.<br>";

	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$phone=$_POST['ph'];
	$address=$_POST['add'];
	$mail=$_POST['mail'];
	$pwd=$_POST['pwd'];
	$city=$_POST['city'];

	$pwd="bd1908".md5($pwd)."am610";

	$sql="INSERT INTO `sign_up` (`u_id`, `f_nm`, `l_nm`, `m_no`, `address`, `email_id`, `password`, `city`) VALUES ('', '$fname', '$lname', '$phone', '$address', '$mail', '$pwd', '$city');";
	echo "$sql";
	if (mysqli_query($con,$sql)) {
		echo "data inserted";
		header('location:login-test.php');
	}	else
	{
		echo "query error".mysqli_error();
	}
?>
