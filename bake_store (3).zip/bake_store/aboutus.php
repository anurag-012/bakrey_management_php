<?php
include 'bake_header.php';
?>
<div class="bake-main">
	<div class="contectus-top">
		<div style="position: relative;">
			<img src="images/about.jpg" width="1000px" height="650px">
			<!-- <div style="position: absolute;top: 0px;color: white;
    width: 431px;
    font-size: 50px;
    font-family: cursive;
    margin-top: 391px;">
				IT STARTED WITH YOU....
			</div> -->
		</div>
	</div>
	<div>
		<div style="font-size: 50px;
    font-family: cursive;
    margin-top: 20px;">
			WE LIKE TO MAKE IT PERSONAL..
		</div>
		<p style="width: 400px;
    display: inline-block;
    font-size: 21px;margin-right: 20px">
			Baking, process of cooking by dry heat, especially in some kind of oven. It is probably the oldest cooking method. Bakery products, which include bread, rolls, cookies, pies, pastries, and muffins, are usually prepared from flour or meal.
		</p>
		<p style="width: 400px;
    display: inline-block;
    font-size: 21px;margin-left: 20px">
			A bakery is an establishment that produces and sells flour-based food baked in an oven such as bread, cookies, cakes, pastries, and pies. Some retail bakeries are also categorized as cafés, serving coffee and tea to customers who wish to consume the baked goods on the premises. ​
		</p>
	</div>
</div>
<?php
include 'bake_footer.php';
?>