<?php
include 'conn.php';
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="homepage.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="Plugins/jquery.chained.selects.js"></script>
<script type="text/javascript" src="Plugins/jquery.validate.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
$("#addressform").validate(
{
rules:
{
fname:'required',
phone:'required',
pin:'required',
add:'required',
state:'required',
city:'required'
}
})
})
</script>

</head>
<body>

<div class="main-division">
<div class="add-main">
<!--  <form id="addressform" action="">-->
<div class="add-title">

</div>
<div>
<div class="sub-title" align="center">
SHIPPING ADDRESS
</div>
<div style="text-align: left;">
<center>
<form action="insert.php">
<br><br><br><br><br>
<input class="inpt2" type="text" name="fname" placeholder="NAME *"><br>
<input class="inpt2" type="text" name="phone" placeholder="MOBILE NO. *"><br>
<input class="inpt2" type="text" name="pin" placeholder="PIN CODE *"><br>
<textarea rows="3" cols="10" class="inpt2" type="text" name="add" placeholder="ADDRESSS(House no,Building,Street,Area) *"></textarea><br>
<input class="inpt2" type="text" name="city" placeholder=" CITY"><br>
<!-- <form action="checkout_submit"> -->
<input class="add-addr" type="submit" name="nm" value="Submit">
</form>
</center>
<script type="text/javascript">
$(document).ready(function(){
function loadData(type, category_id){
$.ajax({
url:"drop_down_code.php",
type:"post",
data: {type : type, id : category_id},
success:function(data){
if(type == "city")
{
$("#city").html(data);
}
else
{
$("#state").append(data);
}
}
});
}
loadData();
$("#state").on("change",function(){
var state=$("#state").val();
loadData("city",state);
})
});
</script>


</body>
</html>