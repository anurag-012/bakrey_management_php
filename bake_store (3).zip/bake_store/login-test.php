<?php
	include ('bake_header.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>login</title>
	<link rel="stylesheet" type="text/css" href="plugins/fancybox/dist/jquery.fancybox.css">
	<!-- <script type="text/javascript" src="plugins/jquery-3.5.1.js"></script> -->
	<script type="text/javascript" src="plugins/fancybox/dist/jquery.fancybox.js"></script>
</head>
<body>
	<div class="bake-main">
		<img src="images/R20dc4c8276e1f22bc05cda6b07ca9747.jpg" height="500px;" width="100%">
		<div class="form-main">
			<div class="fullform">
					<div style="text-align: center;">
						<form id="myform">
							<input class="inpt" type="mail" name="mail" placeholder="Enter your Email" required="">
							<br>
							<input class="inpt" type="password" name="pwd" placeholder="Enter your password" required="" 
							><br>
							<p id="errormsg"></p>
							
							<input class="sub" type="submit" value="Log In">
							
						</form>
						<a href="forgot_pwd_form.php" style="text-decoration: none; 
							color: black;
							font-weight: bold; 
							font-size: 20px;
							margin-top: 30px;">Forgotten Password?</a>
					</div>
					<div class="blank-div-login"></div>
					<div class="form-sub" style="text-align: center; 
											     color: black; 
											     font-weight: bold;
											     margin-top: 10px;">
						Don't Have An Account?<br>
						<div style="font-size: 20px;
									/*border: solid;*/
									width: 50%;
									margin-left: 65px;
									border-radius: 5px;
									background-color: #4a2d2d;
									margin-top: 20px;">
						<a id="inline" href="#data" style="text-decoration: none;
									color: #e0caa8;">Sign Up</a>
						</div>
						<div style="display:none">
							<div id="data">
								<?php
									if(isset($_SESSION['mail'])){
								?>
								<div class="login-txt">Log Out</div>
									<?php
								}	else{
									?>
										<div class="login-txt" style="font-family: 'Poppins', sans-serif;
																	  font-weight: bold;
																	  margin-bottom: 5px;">For joining us please</div>
									<?php
									}
									?>
								<div>
									<div class="signup-txt">
										Sign Up
									</div>
									<!-- <span>
										<img src="images/logo.jpeg" height="90px;" width="90px;">
									</span> -->
	
								</div>
								<form action="signup.php" method="post">
									<input type="text" name="fname" class="uname" placeholder="First name" required=""><br>
									<input type="text" name="lname" class="uname" placeholder="Last name">
									<br>
									<input type="text"  onkeypress="checkphone()" id="n2" name="ph" class="sfrm" placeholder="Phone no." required=""><span id="n2error"></span>
									<br>
									<input type="text"   id="n2" name="add" class="sfrm" placeholder="Address" required=""><span id="n2error"></span>
									<br>
									<input type="Email" name="mail" class="sfrm" placeholder="Email Id" required="">
									<br>
									<input type="password" name="pwd" class="sfrm" placeholder="Password" required="">
									<br>
									<input type="text"   id="n2" name="city" class="sfrm" placeholder="Where are you from" required=""><span id="n2error"></span>
									<br>
									<input type="submit" onclick="checkphone()" name="sub_bt" class="sign-bt" value="Sign Up">
								</form>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	
	<script type="text/javascript">
		$(document).ready(function(){
			$("a#inline").fancybox({
				'hideOnContentClick': true,
				'transition':'elastic'
			});

			function checkphone(){
			var x1 = document.getElementById("n2").value;
			var y1 = document.getElementById("n2error");
			if(x1.length <= 9 || isNaN(x1)){
				
				y1.innerHTML="Please add atleast 10 charcter or add only number ";
			}else{
				y1.innerHTML="";
			}
			}
		});
	</script>
	<script type="text/javascript">
		$(document).ready(function(){
			$("#myform").validate({
				rules:
			{
				mail:
				{
					required: true,
					email:true,
				},
				pwd:
				{
					required: true,
					minlength:5,
					// maxlength:9
				}
			},
			messages:
			{
		
			mail:"enter valid email !!",
			pwd:
			{
				required:"enter password !!",
				minlength:"atleast 8 character or number"
			}
			},
			submitHandler:function(myform)
			{
				$.ajax({
					url:"login_php_code.php",
					type:"post",
					data:$("#myform").serialize(),
					success:function(response)
					{
						$("#errormsg").html(response);
						if (response==".") {
							// alert("login success");
							window.location.href="bake_home.php";
						}
					}
				});
			}
		});
	});
	</script>

<?php
include 'bake_footer.php'
?> 