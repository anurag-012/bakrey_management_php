-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2021 at 07:50 AM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bake_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_mail` varchar(200) NOT NULL,
  `admin_pwd` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_mail`, `admin_pwd`) VALUES
('ami@gmail.com', 'ami123');

-- --------------------------------------------------------

--
-- Table structure for table `admin_product`
--

CREATE TABLE `admin_product` (
  `prod_id` int(11) NOT NULL,
  `prod_type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `admin_product_type`
--

CREATE TABLE `admin_product_type` (
  `prod_type` varchar(200) NOT NULL,
  `type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_product_type`
--

INSERT INTO `admin_product_type` (`prod_type`, `type_id`) VALUES
('cake', 1),
('pastry', 2),
('donuts', 3),
('cookies', 4),
('bread', 5);

-- --------------------------------------------------------

--
-- Table structure for table `admin_prod_images`
--

CREATE TABLE `admin_prod_images` (
  `prod_img_id` int(11) NOT NULL,
  `prod_type` varchar(200) NOT NULL,
  `prod_name` varchar(200) NOT NULL,
  `price` int(200) NOT NULL,
  `prod_img` varchar(100) NOT NULL,
  `type_id` int(11) NOT NULL,
  `discription` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_prod_images`
--

INSERT INTO `admin_prod_images` (`prod_img_id`, `prod_type`, `prod_name`, `price`, `prod_img`, `type_id`, `discription`) VALUES
(19, 'donuts', 'set of 6 donuts', 399, 'images//OIP (20).jpg', 3, 'eggless , home-made , delicious'),
(21, 'cookies', 'oreo cookie', 399, 'images//IMG_9218-homemade-oreos-square.jpg', 4, 'A very delicious home made oreo cookies '),
(22, 'cookies', 'almond cookie', 499, 'images//almond_cookies01181k-480x480.jpg', 4, 'its a very delicious'),
(25, 'cookies', 'cherry choco chips cookie', 299, 'images//Maraschino-Cherry-Chocolate-Chip-Cookies-3.png', 4, 'cherry choco chips cookie are delicious to eat '),
(30, 'pastry', 'red valvet ', 700, 'images/Webp.net-resizeimage_2_966826d1-6a73-41b8-bb4b-7bfe46d457fd_1024x1024.jpg', 2, 'red valvet cake are very tastefull'),
(31, 'cookies', 'red velvet', 200, 'images//b41f3b81b57965d92e378cd24024a895.jpg', 4, 'its a very delicious'),
(32, 'cake', 'chocolate ganache cake', 499, 'images/HK_170108_FerreroRocherCakeEN.jpg', 1, 'its a very delicious'),
(33, 'cake', 'red valvet ', 399, 'images//OIP (5).jpg', 1, 'its a very delicious'),
(34, 'cake', 'ras malai flavour cake', 799, 'images/buttercream-flowers-cake-5.jpg', 1, 'its a very delicious'),
(35, 'cake', 'ferrero rocher cake', 999, 'images/ferrero rocher chocolate cake.jpg', 1, 'its a very delicious'),
(36, 'pastry', 'rainbow pastry', 99, 'images//OIP (24).jpg', 2, 'vcbvbcvbv'),
(38, 'pastry', 'black forest pastry', 89, 'images//BLACK_FOREST_large.png', 2, 'bnbn'),
(39, 'donuts', 'ferrero rocher donut', 199, 'images/0d585f6bdbd415f03cac5898b3261578.jpg', 3, 'its a very delicious'),
(40, 'donuts', 'oreo flavour donut', 149, 'images//eb7537ae4a75e9e28522771228e577c4.jpg', 3, 'its a very delicious'),
(41, 'donuts', 'cheese donuts , set of 3', 499, 'images/OIP (19).jpg', 3, 'its a very delicious');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `inv_id` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `prod_id` int(10) NOT NULL,
  `prod_name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `qty` int(29) NOT NULL,
  `total` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`inv_id`, `email`, `prod_id`, `prod_name`, `price`, `image`, `qty`, `total`) VALUES
(20, 'nim@gmail.com', 30, 'red valvet ', 700, 'images/Webp.net-resizeimage_2_966826d1-6a73-41b8-bb4b-7bfe46d457fd_1024x1024.jpg', 4, 2800),
(21, 'nim@gmail.com', 22, 'almond cookie', 499, 'images//almond_cookies01181k-480x480.jpg', 1, 499),
(23, 'mehul@gmail.com', 35, 'ferrero rocher cake', 899, 'images/ferrero rocher chocolate cake.jpg', 1, 899),
(25, 'mehul@gmail.com', 39, 'ferrero rocher donut', 199, 'images/0d585f6bdbd415f03cac5898b3261578.jpg', 1, 199),
(28, 'mehul@gmail.com', 22, 'almond cookie', 499, 'images//almond_cookies01181k-480x480.jpg', 1, 499),
(31, 'mehul@gmail.com', 32, 'chocolate ganache cake', 499, 'images/HK_170108_FerreroRocherCakeEN.jpg', 1, 499),
(32, 'mehul@gmail.com', 41, 'cheese donuts , set of 3', 499, 'images/OIP (19).jpg', 1, 499);

-- --------------------------------------------------------

--
-- Table structure for table `sign_up`
--

CREATE TABLE `sign_up` (
  `u_id` int(200) NOT NULL,
  `f_nm` varchar(200) NOT NULL,
  `l_nm` varchar(200) NOT NULL,
  `m_no` int(11) NOT NULL,
  `address` varchar(200) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sign_up`
--

INSERT INTO `sign_up` (`u_id`, `f_nm`, `l_nm`, `m_no`, `address`, `email_id`, `password`, `city`) VALUES
(4, 'ami', 'moradiya', 2147483647, 'katargam', 'ami610@gmail.com', 'bd190844346b9fa6e8c62aa33342a8bdfb1bcfam610', 'surat'),
(5, 'nimisha', 'isamaliya', 2147483647, 'katargam', 'nimisha@gmail.com', 'bd1908be016787ef3ea787ed5944c8f80bb352am610', 'surat'),
(6, 'priti ', 'patel', 78787656, 'katargam', 'pritipatel@gmail.com', 'bd19081b486c123e83e26e5ac601d41850460fam610', 'surat'),
(7, 'nenu', 'gabani', 2147483647, 'katargam', 'nenu@gmail.com', 'bd1908e88d1777ca8639fd301c2e1052f1cbc7am610', 'surat'),
(8, 'digna', 'moradiya', 2147483647, 'katargam', 'digna@gmail.com', 'bd1908708321fad9399d50971dcc8fe7936f87am610', 'surat'),
(9, 'samarth', 'moradiya', 67584789, 'katargam', 'sam@gmail.com', 'bd1908ba0e7885b32f0b4b52c51de350069a2fam610', 'surat'),
(10, 'prarthna', 'dhameliya', 879876567, 'katargam', 'pd@gmail.com', 'bd1908bf55109f7e511ebf6d8f1f43a5a96539am610', 'surat'),
(13, 'rutvi', 'gabani', 2147483647, 'ffcde', 'rutvi@gmail.com', 'bd19085865770ecc1b68a6f56ed4bd8926b20cam610', 'rajkot'),
(14, 'rutu', 'diyora', 2147483647, 'ededesd', 'rutu@gmail.com', 'bd19089e3d2b3a26c4ad9b9496abb64726bb46am610', 'gfgfddf'),
(15, 'keyur', 'savani', 2147483647, 'jakatnaka', 'keyur@gmail.com', 'bd1908e19a91ac16816a7c9357ed166a058456am610', 'surat'),
(16, 'ami', 'moradiyaaa', 2147483647, 'ncmnmnmnnm', 'amim@gmail.com', 'bd19080e5b628d048edf98a0e21784d66a8488am610', 'mnmnm'),
(17, 'nimisha', 'isamaliya', 2147483647, 'surat', 'nimi123@gmail.com', 'bd19082871605b2941b9f22a07779d5fe526e5am610', 'surat'),
(18, 'akash', 'italiya', 2147483647, 'dev prayag', 'akash@gmail.com', 'bd1908cb7c5f69ff356ecca55b7d08df877991am610', 'surat'),
(19, 'charmy', 'savani', 2147483647, 'adajan', 'charmy@gmail.com', 'bd1908e10adc3949ba59abbe56e057f20f883eam610', 'surat'),
(20, 'nim', 'isamaliya', 2147483647, 'dfgdfgfgd', 'nim@gmail.com', 'bd1908edaa2dde87aff43371547681e28ccdddam610', 'surat'),
(21, 'rinkal', 'italiya', 78765678, 'katargam', 'adminrinkal@gmail.com', 'bd190832def24a7d78ada7b2b9b05eb76d726aam610', 'surat'),
(22, 'mehul', 'italiya', 2147483647, 'katargam', 'mehul@gmail.com', 'bd190800e06ef794f5c0f4311757a85cebbf3bam610', 'surat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`admin_mail`);

--
-- Indexes for table `admin_product`
--
ALTER TABLE `admin_product`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `admin_product_type`
--
ALTER TABLE `admin_product_type`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `admin_prod_images`
--
ALTER TABLE `admin_prod_images`
  ADD PRIMARY KEY (`prod_img_id`),
  ADD KEY `type_id` (`type_id`),
  ADD KEY `prod_img` (`prod_img`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`inv_id`);

--
-- Indexes for table `sign_up`
--
ALTER TABLE `sign_up`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_prod_images`
--
ALTER TABLE `admin_prod_images`
  MODIFY `prod_img_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `inv_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `sign_up`
--
ALTER TABLE `sign_up`
  MODIFY `u_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_prod_images`
--
ALTER TABLE `admin_prod_images`
  ADD CONSTRAINT `admin_prod_images_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `admin_product_type` (`type_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
