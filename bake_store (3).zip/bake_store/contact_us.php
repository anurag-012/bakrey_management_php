<?php
	include 'bake_header.php';
?>
	<div class="bake-main">
		<div class="contectus-main">
			<div class="contectus-top">
				<div>
				 <img src="images/contact.jpg" width="1086" height="516">
					<div class="contectus-over-content">
						<div class="contectus-img-over-1">
					 		Get In Touch
						</div>
						<div class="contectus-img-over-2">
					 		Want to get in touch? We’d love to hear from you. Here’s how you can reach us…
						</div>
					</div>
				</div>

<!-- ----------------------------------------------------------------------------------------------------- -->

				<div class="four-main" style="overflow: hidden;background-color: #ffebebad">
					<div class="four-sub-top" style="overflow: hidden;">
						<div class="four-sub-top-left">
							<img src="images/talk to sale.jpg" width="100px">
							<div class="four-sub-top-left-txt">
								<div class="talk-to-sale">
								 	Tolk To Sales
								</div>
								<div class="talk-to-sale-content">
								 	Interested in our site? Just email to us..
								</div>
								<div class="mail">
								 	partnership@bakestore22.com
								</div>
							</div>
						</div>
						<div class="four-sub-top-right">
							<img src="images/business-handshake-icon-on-white-background-vector-19944798.jpg" width="100px">
							<div class="four-sub-top-left-txt">
								<div class="adv">
								 	Advertisers
								</div>
								<div class="adv-content">
								 	Contact our ad sales team at...
								</div>
								<div class="mail">
								 	ad@bakestore22.com
								</div>
							</div>
						</div>
					</div>
					<div class="four-sub-bot" style="overflow: hidden;">
						<div class="four-sub-bot-left">
							<img src="images/195146_omhofyaip8hunxoi0ncexyeih.jpg" width="132px">
							<div class="four-sub-top-left-txt">
								<div class="contect-support">
								 	Contect Support
								</div>
								<div class="content-support-content">
								 	Sometimes you need a little help. Don’t worry, We’re here for you.
								</div>
								<div class="mail">
								 	cntct@bakestore22.com
								</div>
							</div>
						</div>
						<div class="four-sub-bot-right">
							<img src="images/img_159810.png" width="100px">
							<div class="four-sub-top-left-txt">
								<div class="privacy">
								 	Privacy
								</div>
								<div class="privacy-content">
								 	Have a privacy policy related question or concern? contact us at...
								</div>
								<div class="mail">
								 	+91 74879 62104 
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php
	include 'bake_footer.php';
?>