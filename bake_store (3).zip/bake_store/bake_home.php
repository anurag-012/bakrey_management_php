<?php
	include('bake_header.php');
?>


	<div class="bake-main">
		<div class="flex-img" style=" overflow: hidden;">
			<div class="flexslider" id="flex">
				<ul class="slides">
					<li>
						<div class="slide-img-3">
							<img src="admin/images/bakery1.jpg">
						
						</div>
					</li>
					
					<li>
						<div class="slide-img-2">
							<img src="admin/images/bakery2.jpg">
							
						</div>
					</li>

					<li>
						<div class="slide-img-1">
							<img src="admin/images/bakery3.jpg">
							
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
<!-- </div> -->
<!------------------------------our category ---------------------------->

<div class="our-cat-main">
			<div class="our-cat-left-line"></div>
			<div class="our-cat-txt"> OUR CATEGORIES </div>
			<div class="our-cat-right-line"></div>
		</div>

<!--------------------------------------------------- -->
<div class="our-cat-pic">
			<a href="product_type.php?id=1">
				<div class="pic-1">
					<img src="images/OIP (8).jpg">
					<div class="txt-over-img-cat">
						<div class="txt-over-img-cat-sub">
							DELICIOUS CAKE
						</div>
					</div>
				</div>
			</a>
			<a href="product_type.php?id=2">
				<div class="pic-2">
					<img src="images/OIP (21).jpg">
					<div class="txt-over-img-cat">
						<div class="txt-over-img-cat-sub">
							PASTRY
						</div>
					</div>
				</div>
			</a>
			<a href="product_type.php?id=3">
				<div class="pic-3">
					<img src="images/OIP (20).jpg">
					<div class="txt-over-img-cat">
						<div class="txt-over-img-cat-sub">
							DONUTS
						</div>
					</div>
				</div>
			</a>
			<a href="prod_type.php?id=4">
				<div class="pic-4">
					<img src="images/OIP (13).jpg">
					<div class="txt-over-img-cat">
						<div class="txt-over-img-cat-sub">
							COOKIES
						</div>
					</div>
				</div>
			</a>
			<!-- <a href="">
				<div class="pic-5">
					<img src="image/Innisfree+Sheet+Face+Masks.jpg" height="300px" width="300px">
					<div class="txt-over-img-cat">
						<div class="txt-over-img-cat-sub">
							FACIAL MASKS
						</div>
					</div>
				</div>
			</a> -->
		</div>

<!------------------------------ feedback ---------------------------------->
<div class="offers-bar" style="margin-top: 90px;">
			<div class="customer-service-main">
			 	<div class="customer-service-icon">
			 		<img src="images/customer-care-87-1131395.webp" width="70px">
			 	</div>
			 	<div class="customer-service-txt">
			 		<p>
			 			CUSTOMER SERVICES
			 		</p>
			 	</div>
			 	<div class="customer-service-disc">
			 		<p>
			 			As much as i'd love to help , your request is beyond what we are able to do for customers.  
			 		</p>
			 	</div>
			</div>

			<div class="free-shipping-main">
			 	<div class="free-shipping-icon">
			 		<img src="images/free-shipping-2493813-2086149.png" width="70px">
			 	</div>
			 	<div class="free-shipping-txt">
			 		<p>
			 			FREE SHIPPING
			 		</p>
			 	</div>
			 	<div class="free-shipping-disc">
			 		<p>
			 			Hurry up! Spend more and save more with our free shipping days sale. 
			 		</p>
			 	</div>
			</div>

			<div class="money-back-main">
			 	<div class="monet-back-icon">
			 		<img src="images/445105-200.png" width="70px">
			 	</div>
			 	<div class="money-back-txt">
			 		<p>
			 			MONEY BACK
			 		</p>
			 	</div>
			 	<div class="money-back-disc">
			 		<p>
			 			As much as i'd love to help , your request is beyond what we are able to do for customers.  
			 		</p>
			 	</div>
			 </div>
		</div>

		<!-- ------------------------------------------------------------------------------------------------ -->

		<div class="last-second-flex">
			<div class="last-second-flex-sub">
				<div class="review-txt">
					REVIEWS
				</div>
				<div class="flexslider" id="flex-last" style="border: none;">
					<ul class="slides">
						<li>
							<div class="slide-img-1">
								<div class="review-main">
									<p class="review-content-txt">
									Wow! Super cute place with amazing pastries. The staff was also super nice and welcoming. Definitely recommend a trip!
									</p>
									<div class="viewer-name">
										- Divyanshi Jain 
									</div>
								</div>
							</div>
						</li>
						<li>
							<div class="slide-img-1">
								<!-- <div class="sign">
									<img src="images/fd1.jpg" height="50px;" width="50px;">
								</div> -->
								<div class="review-main">
								<p class="review-content-txt">
								Such a gem! Not only are the staff and pastries / donuts incredible, you can’t beat the prices and supporting local! Get here ASAP!  
								</p>
								<div class="viewer-name">
									- Rohan
								</div>
							</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
<?php
include 'bake_footer.php'
?> 